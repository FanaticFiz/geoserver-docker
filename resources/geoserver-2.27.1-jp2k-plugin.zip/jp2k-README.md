In order to install the ImageIO-Ext Kakadu extensions you have to:
* copy all the jars contained in this package into geoserver/WEB-INF/lib
* properly install the native binary libraries for your operating system